
package notas_g1;

/**
 *
 * @author FaMel
 */
public class Notas_G1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
